import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from plotly.subplots import make_subplots
import plotly.graph_objects as go
from wordcloud import WordCloud, STOPWORDS
import matplotlib.pyplot as plt
import nltk
from nltk.corpus import stopwords
import base64
from datetime import datetime
from textblob import TextBlob


# Ensure NLTK resources are downloaded
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')
try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords')

# Path to your data file - users will need to modify this
DATA_URL = r"C:\Users\Student\Documents\AirlineDashboard\Tweets.csv"  # Changed to relative path for easier use

# Set page configuration
st.set_page_config(
    page_title="Airline Sentiment Dashboard",
    page_icon="✈️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for modern design
def apply_custom_css():
    st.markdown("""
    <style>
    /* Main page background */
    .stApp {
        background-color: #f8f9fa;
    }
    
    /* Headings */
    h1, h2, h3 {
        color: #1a237e;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    h1 {
        font-size: 2.5rem;
        margin-bottom: 1rem;
        text-align: center;
        color: #1a237e;
        padding: 0.5rem;
        border-bottom: 2px solid #3949ab;
    }
    
    h3 {
        background-color: #3949ab;
        color: white;
        padding: 0.7rem;
        border-radius: 7px;
        font-size: 1.2rem;
        margin-top: 1rem;
    }
    
    /* Card-like containers */
    .css-1r6slb0, .css-keje6w {
        background-color: white;
        border-radius: 10px;
        padding: 1.5rem;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
        margin-bottom: 1rem;
    }
    
    /* Sidebar styling */
    .css-1lcbmhc, .css-1d391kg {
        background-color: #1a237e;
        color: white;
    }
    
    .css-1lcbmhc .block-container, .css-1d391kg .block-container {
        padding-top: 2rem;
    }
    
    /* Sidebar text */
    .css-1lcbmhc h2, .css-1d391kg h2 {
        color: white;
    }
    
    /* Sidebar labels */
    .css-10trblm {
        color: #3949ab;
        font-weight: bold;
        margin-top: 1rem;
    }
    
    /* Button styling */
    .stButton>button {
        background-color: #3949ab;
        color: white;
        font-weight: bold;
        border: none;
        border-radius: 5px;
        padding: 0.5rem 1rem;
    }
    
    .stButton>button:hover {
        background-color: #1a237e;
    }
    
    /* Metric cards */
    .metric-card {
        background-color: white;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
        padding: 1.2rem;
        text-align: center;
        height: 100%;
    }
    
    .metric-value {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1a237e;
        margin: 0.5rem 0;
    }
    
    .metric-label {
        font-size: 1rem;
        color: #5c6bc0;
        text-transform: uppercase;
        letter-spacing: 1px;
    }
    
    .metric-change {
        font-size: 0.9rem;
        margin-top: 0.5rem;
    }
    
    .positive-change {
        color: #2ecc71;
    }
    
    .negative-change {
        color: #e74c3c;
    }
    
    .neutral-change {
        color: #f39c12;
    }
    
    /* Chart container */
    .chart-container {
        background-color: white;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
        padding: 1rem;
        margin-bottom: 1rem;
    }
    
    /* Plotly charts */
    .js-plotly-plot {
        margin: 0 auto;
    }
    
    /* Data tables */
    .stDataFrame {
        border-radius: 10px;
        overflow: hidden;
    }
    
    /* Logo and navigation */
    .logo-title {
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 2rem;
    }
    
    </style>
    """, unsafe_allow_html=True)

apply_custom_css()

# App header with logo and title
def app_header():
    col1, col2 = st.columns([1, 5])
    with col1:
        # Using an airplane emoji as a logo
        st.markdown("""
        <div style="font-size: 3rem; text-align: center;">✈️</div>
        """, unsafe_allow_html=True)
    with col2:
        st.markdown("""
        <h1>US Airlines Sentiment Dashboard</h1>
        <p style="text-align: center; color: #7f8c8d;">Interactive analysis of customer tweets and sentiment</p>
        """, unsafe_allow_html=True)

app_header()


# Define functions for data loading and processing
@st.cache_data
def load_data():
    try:
        data = pd.read_csv(DATA_URL)
        data['tweet_created'] = pd.to_datetime(data['tweet_created'])
        data['textblob_sentiment'] = data['text'].apply(lambda x: 
            'positive' if TextBlob(x).sentiment.polarity > 0 
            else 'negative' if TextBlob(x).sentiment.polarity < 0 
            else 'neutral')
        return data
    except FileNotFoundError:
        st.error(f"Data file not found: {DATA_URL}")
        return pd.DataFrame()  # Return empty DataFrame if file not found

# Initialize stopwords for word cloud
stop_words = set(stopwords.words('english'))
stop_words.update([',',';','!','?','.','(',')','$','#','+',':','...'])

# Load the data
try:
    data = load_data()
    if data.empty:
        st.error("Unable to load data. Please check the file path.")
        st.markdown("""
        ### Required Data Format
        
        This dashboard requires a CSV file with the following columns:
        - `airline_sentiment`: The sentiment of the tweet (positive, neutral, negative)
        - `airline`: The airline mentioned in the tweet
        - `text`: The text content of the tweet
        - `tweet_created`: The timestamp when the tweet was created
        
        Optional columns:
        - `latitude` and `longitude`: Coordinates for mapping tweets
        - `negativereason`: The reason for negative sentiment
        """)
    else:
        # Sidebar navigation
        st.sidebar.markdown("""
        <div style="text-align: center; padding: 1rem 0;">
            <h2 style="color: black;">Dashboard Controls</h2>
        </div>
        """, unsafe_allow_html=True)
        
        section = st.sidebar.radio(
            "Navigate To:",
            ["Overview", "Sentiment Analysis", "Airline Comparison", "Time Analysis", "Word Cloud Analysis","Geographic Analysis"]
        )
        
        # Display a random tweet in sidebar
        st.sidebar.markdown("---")
        st.sidebar.subheader("📌 Random Tweet Sample")
        
        random_tweet = st.sidebar.selectbox(
            'Sentiment Type:', 
            ('positive', 'neutral', 'negative'),
            key='sentiment_radio'
        )
        
        try:
            random_sample = data.query("airline_sentiment == @random_tweet")[["text"]].sample(n=1).iat[0, 0]
            st.sidebar.markdown(f"""
            <div style="background-color: s; border-radius: 10px; padding: 10px; margin-top: 10px;">
                <p style="font-style: italic; color: #000000;">"{random_sample}"</p>
            </div>
            """, unsafe_allow_html=True)
        except IndexError:
            st.sidebar.warning("No tweets available for this sentiment")
        
        # Add current time to sidebar
        st.sidebar.markdown("---")
        current_time = datetime.now().strftime("%b %d, %Y %H:%M")
        st.sidebar.markdown(f"""
        <div style="position: absolute; bottom: 20px; left: 20px; right: 20px; text-align: center; color: #bdc3c7;">
            <p>Last updated: {current_time}</p>
            <p>Group 5 Dashboard</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Calculate key metrics for dashboard
        total_tweets = len(data)
        sentiment_counts = data['airline_sentiment'].value_counts()
        airlines = data['airline'].value_counts()
        
        # SECTION: OVERVIEW DASHBOARD
        if section == "Overview":
            # Key metrics in cards
            st.markdown("### 📊 Key Metrics")
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.markdown("""
                <div class="metric-card">
                    <div class="metric-label">Total Tweets</div>
                    <div class="metric-value">{:,}</div>
                </div>
                """.format(total_tweets), unsafe_allow_html=True)
                
            with col2:
                positive_pct = round((sentiment_counts.get('positive', 0) / total_tweets) * 100, 1)
                st.markdown("""
                <div class="metric-card">
                    <div class="metric-label">Positive Sentiment</div>
                    <div class="metric-value">{:.1f}%</div>
                </div>
                """.format(positive_pct), unsafe_allow_html=True)
                
            with col3:
                negative_pct = round((sentiment_counts.get('negative', 0) / total_tweets) * 100, 1)
                st.markdown("""
                <div class="metric-card">
                    <div class="metric-label">Negative Sentiment</div>
                    <div class="metric-value">{:.1f}%</div>
                </div>
                """.format(negative_pct), unsafe_allow_html=True)
                
            with col4:
                top_airline = airlines.index[0]
                top_airline_count = airlines.iloc[0]
                st.markdown("""
                <div class="metric-card">
                    <div class="metric-label">Top Airline</div>
                    <div class="metric-value">{}</div>
                    <div class="metric-change">{:,} tweets</div>
                </div>
                """.format(top_airline, top_airline_count), unsafe_allow_html=True)
            
            # Sentiment Distribution
            st.markdown("### 📈 Sentiment Distribution")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown('<div class="chart-container">', unsafe_allow_html=True)
                sentiment_df = pd.DataFrame({
                    'Sentiment': sentiment_counts.index,
                    'Count': sentiment_counts.values
                })
                
                colors = {'positive': '#2ecc71', 'neutral': '#f39c12', 'negative': '#e74c3c'}
                
                fig = px.bar(sentiment_df, x='Sentiment', y='Count',
                             color='Sentiment', color_discrete_map=colors,
                             title="Overall Sentiment Distribution")
                
                fig.update_layout(
                    plot_bgcolor='rgba(0,0,0,0)',
                    paper_bgcolor='rgba(0,0,0,0)',
                    title_font_size=18,
                    title_x=0.5,
                    xaxis_title="",
                    yaxis_title="Number of Tweets",
                    legend_title="Sentiment"
                )
                
                st.plotly_chart(fig, use_container_width=True)
                st.markdown('</div>', unsafe_allow_html=True)
            
            with col2:
                st.markdown('<div class="chart-container">', unsafe_allow_html=True)
                fig = px.pie(sentiment_df, values='Count', names='Sentiment',
                             color='Sentiment', color_discrete_map=colors,
                             title="Sentiment Proportion")
                
                fig.update_layout(
                    plot_bgcolor='rgba(0,0,0,0)',
                    paper_bgcolor='rgba(0,0,0,0)',
                    title_font_size=18,
                    title_x=0.5,
                    legend_title="Sentiment"
                )
                
                st.plotly_chart(fig, use_container_width=True)
                st.markdown('</div>', unsafe_allow_html=True)
            
            # Airline Comparison
            st.markdown("### ✈️ Airline Tweet Volume")
            st.markdown('<div class="chart-container">', unsafe_allow_html=True)
            
            airline_df = pd.DataFrame({
                'Airline': airlines.index,
                'Tweets': airlines.values
            })
            
            fig = px.bar(airline_df, x='Airline', y='Tweets', color='Tweets',
                         color_continuous_scale=px.colors.sequential.Viridis,
                         title="Number of Tweets by Airline")
            
            fig.update_layout(
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
                title_font_size=18,
                title_x=0.5,
                xaxis_title="",
                yaxis_title="Number of Tweets"
            )
            
            st.plotly_chart(fig, use_container_width=True)
            st.markdown('</div>', unsafe_allow_html=True)
            
            # Tweet activity over time
            st.markdown("### 📅 Tweet Activity Over Time")
            st.markdown('<div class="chart-container">', unsafe_allow_html=True)
            
            # Group by date and count tweets
            data['date'] = data['tweet_created'].dt.date
            date_counts = data.groupby('date').size().reset_index(name='count')
            
            fig = px.line(date_counts, x='date', y='count',
                          title="Tweet Volume Over Time")
            
            fig.update_layout(
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)',
                title_font_size=18,
                title_x=0.5,
                xaxis_title="Date",
                yaxis_title="Number of Tweets"
            )
            
            st.plotly_chart(fig, use_container_width=True)
            st.markdown('</div>', unsafe_allow_html=True)

            if 'name' in data.columns:
                st.markdown("### Top 20 Most Active Users")
                top_users = data['name'].value_counts().nlargest(20).reset_index()
                top_users.columns = ['User', 'Tweet Count']
                fig = px.bar(top_users, x='User', y='Tweet Count', 
                            title='Most Frequent Tweeters',
                            color='Tweet Count', 
                            color_continuous_scale='Viridis')
                fig.update_layout(xaxis_tickangle=45)
                st.plotly_chart(fig, use_container_width=True)
        
        # SECTION: SENTIMENT ANALYSIS
        elif section == "Sentiment Analysis":
            st.markdown("## Detailed Sentiment Analysis")
            
            # Select airlines for analysis
            airlines_list = sorted(data['airline'].unique())
            selected_airlines = st.multiselect(
                "Select Airlines for Analysis:",
                airlines_list,
                default=airlines_list[:3]
            )
            
            if not selected_airlines:
                st.warning("Please select at least one airline")
            else:
                # Filter data for selected airlines
                filtered_data = data[data['airline'].isin(selected_airlines)]
                
                # Sentiment breakdown by airline
                st.markdown("### Sentiment Distribution by Airline")
                
                
                # Create a dataframe with sentiment counts for each airline
                sentiment_by_airline = filtered_data.groupby(['airline', 'airline_sentiment']).size().unstack(fill_value=0)
                
                # Visualization type selector
                viz_type = st.radio(
                    "Choose visualization type:",
                    ["Bar Chart", "Stacked Bar", "Pie Charts"],
                    horizontal=True
                )
                
                if viz_type == "Bar Chart":
                    # Prepare data for bar chart
                    chart_data = []
                    for airline in selected_airlines:
                        airline_data = data[data['airline'] == airline]
                        sentiments = airline_data['airline_sentiment'].value_counts()
                        for sentiment, count in sentiments.items():
                            chart_data.append({
                                'Airline': airline,
                                'Sentiment': sentiment,
                                'Count': count
                            })
                    
                    chart_df = pd.DataFrame(chart_data)
                    
                    # Create grouped bar chart
                    fig = px.bar(chart_df, x='Airline', y='Count', color='Sentiment',
                                 color_discrete_map={'positive': '#2ecc71', 'neutral': '#f39c12', 'negative': '#e74c3c'},
                                 barmode='group')
                    
                    fig.update_layout(
                        plot_bgcolor='rgba(0,0,0,0)',
                        paper_bgcolor='rgba(0,0,0,0)',
                        legend_title="Sentiment",
                        xaxis_title="",
                        yaxis_title="Number of Tweets"
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                
                elif viz_type == "Stacked Bar":
                    # Same data, but stacked presentation
                    chart_data = []
                    for airline in selected_airlines:
                        airline_data = data[data['airline'] == airline]
                        sentiments = airline_data['airline_sentiment'].value_counts()
                        for sentiment, count in sentiments.items():
                            chart_data.append({
                                'Airline': airline,
                                'Sentiment': sentiment,
                                'Count': count
                            })
                    
                    chart_df = pd.DataFrame(chart_data)
                    
                    # Create stacked bar chart
                    fig = px.bar(chart_df, x='Airline', y='Count', color='Sentiment',
                                 color_discrete_map={'positive': '#2ecc71', 'neutral': '#f39c12', 'negative': '#e74c3c'},
                                 barmode='stack')
                    
                    fig.update_layout(
                        plot_bgcolor='rgba(0,0,0,0)',
                        paper_bgcolor='rgba(0,0,0,0)',
                        legend_title="Sentiment",
                        xaxis_title="",
                        yaxis_title="Number of Tweets"
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                
                else:  # Pie Charts
                    # Create subplots for pie charts
                    cols = min(3, len(selected_airlines))
                    rows = (len(selected_airlines) + cols - 1) // cols
                    
                    fig = make_subplots(rows=rows, cols=cols, specs=[[{'type':'domain'}]*cols] * rows,
                                        subplot_titles=selected_airlines)
                    
                    colors = {'positive': '#2ecc71', 'neutral': '#f39c12', 'negative': '#e74c3c'}
                    
                    for i, airline in enumerate(selected_airlines):
                        row = i // cols + 1
                        col = i % cols + 1
                        
                        airline_data = data[data['airline'] == airline]
                        sentiment_counts = airline_data['airline_sentiment'].value_counts()
                        
                        fig.add_trace(
                            go.Pie(
                                labels=sentiment_counts.index,
                                values=sentiment_counts.values,
                                marker=dict(colors=[colors[s] for s in sentiment_counts.index]),
                                hoverinfo='label+percent',
                                textinfo='percent',
                                hole=0.3
                            ),
                            row=row, col=col
                        )
                    
                    fig.update_layout(
                        height=300 * rows,
                        title_text="Sentiment Distribution by Airline",
                        title_font_size=18,
                        title_x=0.5,
                        showlegend=True
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                
                # Sentiment percentage metrics
                st.markdown("### Sentiment Percentages by Airline")
                
                # Calculate percentages
                sentiment_percentages = []
                for airline in selected_airlines:
                    airline_data = data[data['airline'] == airline]
                    total = len(airline_data)
                    
                    pos_count = len(airline_data[airline_data['airline_sentiment'] == 'positive'])
                    neu_count = len(airline_data[airline_data['airline_sentiment'] == 'neutral'])
                    neg_count = len(airline_data[airline_data['airline_sentiment'] == 'negative'])
                    
                    sentiment_percentages.append({
                        'Airline': airline,
                        'Positive': round(pos_count / total * 100, 1),
                        'Neutral': round(neu_count / total * 100, 1),
                        'Negative': round(neg_count / total * 100, 1),
                        'Total Tweets': total
                    })
                
                # Display as a table
                st.table(pd.DataFrame(sentiment_percentages).set_index('Airline'))
                
                # Additional analysis: reasons for negative sentiment
                if 'negativereason' in data.columns:
                    st.markdown("### Reasons for Negative Sentiment")
                    
                    negative_data = filtered_data[filtered_data['airline_sentiment'] == 'negative']
                    
                    if not negative_data.empty:
                        reasons = negative_data['negativereason'].value_counts().reset_index()
                        reasons.columns = ['Reason', 'Count']
                        
                        # Filter out None/NaN reasons
                        reasons = reasons[reasons['Reason'].notna()]
                        
                        if not reasons.empty:
                            fig = px.bar(reasons, x='Reason', y='Count', color='Count',
                                        color_continuous_scale=px.colors.sequential.Reds)
                            
                            fig.update_layout(
                                plot_bgcolor='rgba(0,0,0,0)',
                                paper_bgcolor='rgba(0,0,0,0)',
                                xaxis_title="",
                                yaxis_title="Number of Tweets",
                                xaxis={'categoryorder':'total descending'}
                            )
                            
                            st.plotly_chart(fig, use_container_width=True)
                        else:
                            st.info("No specific negative reasons found in the data")
                    else:
                        st.info("No negative sentiment data available for the selected airlines")
                # 1. TEXTBLOB COMPARISON
                st.markdown("### TextBlob vs Airline Sentiment Comparison")
                
                comparison_matrix = data.groupby(
                    ['airline_sentiment', 'textblob_sentiment']
                ).size().unstack(fill_value=0)
                
                fig = px.imshow(
                    comparison_matrix,
                    labels=dict(x="TextBlob Sentiment", y="Airline Sentiment", color="Count"),
                    x=comparison_matrix.columns,
                    y=comparison_matrix.index,
                    color_continuous_scale='Blues',
                    text_auto=True
                )
                fig.update_layout(
                    title='Agreement Between Airline Sentiment and TextBlob Sentiment',
                    plot_bgcolor='rgba(0,0,0,0)',
                    paper_bgcolor='rgba(0,0,0,0)'
                )
                st.plotly_chart(fig, use_container_width=True)
                
                # 2. CONFIDENCE SCORES
                st.markdown("### Sentiment Confidence Distribution")
                
                fig = px.histogram(
                    data,
                    x='airline_sentiment_confidence',
                    nbins=30,
                    color='airline_sentiment',
                    color_discrete_map={
                        'positive': '#2ecc71',
                        'neutral': '#f39c12',
                        'negative': '#e74c3c'
                    },
                    title='Airline Sentiment Confidence Scores'
                )
                fig.update_layout(
                    xaxis_title='Confidence Score',
                    yaxis_title='Tweet Count',
                    plot_bgcolor='rgba(0,0,0,0)',
                    paper_bgcolor='rgba(0,0,0,0)'
                )
                st.plotly_chart(fig, use_container_width=True)
                
                # 3. NEGATIVE REASON CONFIDENCE 
                if 'negativereason_confidence' in data.columns:
                    st.markdown("### Negative Reason Confidence Distribution")
                    
                    neg_df = data[data['negativereason'] != 'None']
                    
                    fig = px.histogram(
                        neg_df,
                        x='negativereason_confidence',
                        nbins=30,
                        color='negativereason',
                        title='Confidence in Negative Reasons'
                    )
                    fig.update_layout(
                        xaxis_title='Confidence Score',
                        yaxis_title='Count',
                        plot_bgcolor='rgba(0,0,0,0)',
                        paper_bgcolor='rgba(0,0,0,0)'
                    )
                    st.plotly_chart(fig, use_container_width=True)
                        
   
        
        # SECTION: AIRLINE COMPARISON
        elif section == "Airline Comparison":
            st.markdown("## Airline Performance Comparison")
            
            # Select airlines to compare
            airlines_list = sorted(data['airline'].unique())
            compare_airlines = st.multiselect(
                "Select Airlines to Compare:",
                airlines_list,
                default=airlines_list if len(airlines_list) <= 4 else airlines_list[:4]
            )
            
            if len(compare_airlines) < 2:
                st.warning("Please select at least two airlines for comparison")
            else:
                # Filter data for selected airlines
                compare_data = data[data['airline'].isin(compare_airlines)]
                
                # Create airline comparison metrics
                st.markdown("### Key Metrics Comparison")
                
                metrics = []
                for airline in compare_airlines:
                    airline_data = data[data['airline'] == airline]
                    total = len(airline_data)
                    
                    # Calculate sentiment percentages
                    pos_pct = round(len(airline_data[airline_data['airline_sentiment'] == 'positive']) / total * 100, 1)
                    neg_pct = round(len(airline_data[airline_data['airline_sentiment'] == 'negative']) / total * 100, 1)
                    
                    # Calculate sentiment ratio (positive to negative)
                    pos_count = len(airline_data[airline_data['airline_sentiment'] == 'positive'])
                    neg_count = len(airline_data[airline_data['airline_sentiment'] == 'negative'])
                    sentiment_ratio = round(pos_count / max(neg_count, 1), 2)  # Avoid division by zero
                    
                    metrics.append({
                        'Airline': airline,
                        'Total Tweets': total,
                        'Positive %': pos_pct,
                        'Negative %': neg_pct,
                        'Pos:Neg Ratio': sentiment_ratio
                    })
                
                # Display metrics as a table
                st.table(pd.DataFrame(metrics).set_index('Airline'))
                
                # Create radar chart for comparison
                st.markdown("### Sentiment Profile Comparison")
                
                fig = go.Figure()
                
                for airline in compare_airlines:
                    airline_data = data[data['airline'] == airline]
                    total = len(airline_data)
                    
                    # Calculate sentiment percentages
                    pos_pct = round(len(airline_data[airline_data['airline_sentiment'] == 'positive']) / total * 100, 1)
                    neu_pct = round(len(airline_data[airline_data['airline_sentiment'] == 'neutral']) / total * 100, 1)
                    neg_pct = round(len(airline_data[airline_data['airline_sentiment'] == 'negative']) / total * 100, 1)
                    
                    # If negativereason exists, get top reason percentage
                    top_reason_pct = 0
                    if 'negativereason' in airline_data.columns:
                        neg_data = airline_data[airline_data['airline_sentiment'] == 'negative']
                        if not neg_data.empty:
                            reasons = neg_data['negativereason'].value_counts()
                            if not reasons.empty:
                                top_reason = reasons.index[0]
                                top_reason_count = reasons.iloc[0]
                                top_reason_pct = round(top_reason_count / len(neg_data) * 100, 1)
                    
                    # Add trace for this airline
                    fig.add_trace(go.Scatterpolar(
                        r=[pos_pct, 100-neg_pct, neu_pct, total/data.shape[0]*100, 100-top_reason_pct],
                        theta=['Positive %', 'Satisfaction', 'Neutral %', 'Tweet Volume', 'Issue Diversity'],
                        fill='toself',
                        name=airline
                    ))
                
                fig.update_layout(
                    polar=dict(
                        radialaxis=dict(
                            visible=True,
                            range=[0, 100]
                        )
                    ),
                    showlegend=True
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                # Additional comparison: Tweet volume over time
                st.markdown("### Tweet Volume Comparison Over Time")
                
                # Group by airline and date
                compare_data['date'] = compare_data['tweet_created'].dt.date
                time_comparison = compare_data.groupby(['airline', 'date']).size().reset_index(name='count')
                
                # Create time series chart
                fig = px.line(time_comparison, x='date', y='count', color='airline',
                             title="Tweet Volume by Airline Over Time")
                
                fig.update_layout(
                    plot_bgcolor='rgba(0,0,0,0)',
                    paper_bgcolor='rgba(0,0,0,0)',
                    xaxis_title="Date",
                    yaxis_title="Number of Tweets",
                    legend_title="Airline"
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                # Show tweet examples
                st.markdown("### Sample Tweets for Each Airline")
                
                for airline in compare_airlines:
                    with st.expander(f"Sample tweets for {airline}"):
                        airline_data = data[data['airline'] == airline]
                        
                        # Get one example of each sentiment type
                        pos_example = airline_data[airline_data['airline_sentiment'] == 'positive']['text'].sample(n=1).iloc[0] if not airline_data[airline_data['airline_sentiment'] == 'positive'].empty else "No positive examples found"
                        neu_example = airline_data[airline_data['airline_sentiment'] == 'neutral']['text'].sample(n=1).iloc[0] if not airline_data[airline_data['airline_sentiment'] == 'neutral'].empty else "No neutral examples found"
                        neg_example = airline_data[airline_data['airline_sentiment'] == 'negative']['text'].sample(n=1).iloc[0] if not airline_data[airline_data['airline_sentiment'] == 'negative'].empty else "No negative examples found"
                        
                        st.markdown(f"**Positive example:**\n> {pos_example}")
                        st.markdown(f"**Neutral example:**\n> {neu_example}")
                        st.markdown(f"**Negative example:**\n> {neg_example}")
        
        # SECTION: TIME ANALYSIS
        elif section == "Time Analysis":
            st.markdown("## Time-Based Analysis")
            
            # Add hour selector
            hour_range = st.slider(
                "Select hour range to analyze:", 
                0, 23, (0, 23)
            )
            
            # Filter data by selected hours
            hourly_data = data[data['tweet_created'].dt.hour.between(hour_range[0], hour_range[1])]
            
            if hourly_data.empty:
                st.warning("No data available for the selected time range")
            else:
                # Display tweet count for selected time range
                st.markdown(f"### Analysis of {len(hourly_data)} tweets between {hour_range[0]}:00 and {hour_range[1]}:00")
                
                # Distribution of tweets by hour
                st.markdown("### Tweet Volume by Hour of Day")
                
                hourly_counts = data.groupby(data['tweet_created'].dt.hour).size().reset_index(name='count')
                hourly_counts.columns = ['Hour', 'Count']
                
                # Highlight the selected range
                hourly_counts['Selected'] = hourly_counts['Hour'].apply(
                    lambda x: 'Selected' if hour_range[0] <= x <= hour_range[1] else 'Not Selected'
                )
                
                fig = px.bar(hourly_counts, x='Hour', y='Count', 
                         color='Selected', 
                         color_discrete_map={'Selected': '#3498db', 'Not Selected': '#bdc3c7'},
                         labels={'Hour': 'Hour of Day', 'Count': 'Number of Tweets'})

                fig.update_layout(
                    plot_bgcolor='rgba(0,0,0,0)',
                    paper_bgcolor='rgba(0,0,0,0)',
                    xaxis=dict(tickmode='linear', tick0=0, dtick=1),
                    xaxis_title="Hour of Day",
                    yaxis_title="Number of Tweets",
                    legend_title="Time Range"
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                # Sentiment distribution by hour
                st.markdown("### Sentiment Distribution by Hour")
                
                # Group by hour and sentiment
                hourly_sentiment = data.groupby([data['tweet_created'].dt.hour, 'airline_sentiment']).size().reset_index(name='count')
                hourly_sentiment.columns = ['Hour', 'Sentiment', 'Count']
                
                # Filter to selected hours
                hourly_sentiment = hourly_sentiment[hourly_sentiment['Hour'].between(hour_range[0], hour_range[1])]
                
                fig = px.bar(hourly_sentiment, x='Hour', y='Count', color='Sentiment',
                             color_discrete_map={'positive': '#2ecc71', 'neutral': '#f39c12', 'negative': '#e74c3c'},
                             barmode='group')
                
                fig.update_layout(
                    plot_bgcolor='rgba(0,0,0,0)',
                    paper_bgcolor='rgba(0,0,0,0)',
                    xaxis=dict(tickmode='linear', tick0=0, dtick=1),
                    xaxis_title="Hour of Day",
                    yaxis_title="Number of Tweets",
                    legend_title="Sentiment"
                )
                
                st.plotly_chart(fig, use_container_width=True)
                
                # Tweet location map
                st.markdown("### Tweet Locations for Selected Time Range")
                
                # Check if latitude and longitude columns exist
                if all(col in hourly_data.columns for col in ['tweet_lat', 'tweet_long']):
                    # Filter only tweets with valid coordinates
                    map_data = hourly_data[hourly_data['tweet_lat'].notna() & hourly_data['tweet_long'].notna()]
                    
                    if not map_data.empty:
                        # Create a copy to avoid modifying the original dataframe
                        map_display = map_data[['tweet_lat', 'tweet_long']].copy()
                        map_display.columns = ['lat', 'lon']
                        
                        st.map(map_display)
                    else:
                        st.info("No location data available for the selected time range")
                else:
                    st.info("Location data not available in the dataset")
                
                # Show hourly data statistics
                with st.expander("View Hourly Data Statistics"):
                    # Calculate statistics for each hour in the selected range
                    hour_stats = []
                    
                    for hour in range(hour_range[0], hour_range[1] + 1):
                        hour_data = data[data['tweet_created'].dt.hour == hour]
                        total = len(hour_data)
                        
                        if total > 0:
                            pos_count = len(hour_data[hour_data['airline_sentiment'] == 'positive'])
                            neu_count = len(hour_data[hour_data['airline_sentiment'] == 'neutral'])
                            neg_count = len(hour_data[hour_data['airline_sentiment'] == 'negative'])
                            
                            hour_stats.append({
                                'Hour': f"{hour}:00",
                                'Total Tweets': total,
                                'Positive': pos_count,
                                'Neutral': neu_count,
                                'Negative': neg_count,
                                'Positive %': round(pos_count / total * 100, 1),
                                'Negative %': round(neg_count / total * 100, 1)
                            })
                    
                    if hour_stats:
                        stats_df = pd.DataFrame(hour_stats).set_index('Hour')
                        st.table(stats_df)
                    else:
                        st.info("No data available for the selected hours")

        
        elif section == "Geographic Analysis":
            st.markdown("## 🌍 Geographic Analysis of Tweets")
            
            # Check if we have geographic data
            if 'latitude' not in data.columns or 'longitude' not in data.columns:
                st.warning("Geographic coordinates (latitude/longitude) not available in this dataset")
            else:
                # Filter out tweets without location data
                geo_data = data[data['latitude'].notna() & data['longitude'].notna()].copy()
                
                if geo_data.empty:
                    st.warning("No tweets with geographic coordinates available")
                else:
                    # Convert to numeric (in case stored as strings)
                    geo_data['latitude'] = pd.to_numeric(geo_data['latitude'])
                    geo_data['longitude'] = pd.to_numeric(geo_data['longitude'])
                    
                    # Create approximate location bins (rounded to 1 decimal place)
                    geo_data['approx_location'] = geo_data.apply(
                        lambda x: f"{round(x['latitude'], 1)},{round(x['longitude'], 1)}", 
                        axis=1
                    )
                    
                    # 1. WORLD MAP VISUALIZATION
                    st.markdown("### Tweet Locations Worldwide")
                    
                    # Create map dataframe with consistent column names
                    map_df = geo_data[['latitude', 'longitude', 'airline_sentiment', 'airline']].copy()
                    map_df.columns = ['lat', 'lon', 'sentiment', 'airline']
                    
                    # Show basic map
                    st.map(map_df)
                    
                    # 2. INTERACTIVE PLOTLY MAP
                    st.markdown("### Interactive Sentiment Map")
                    
                    # Color mapping for sentiments
                    color_discrete_map = {
                        'positive': '#2ecc71',  # Green
                        'neutral': '#f39c12',   # Orange
                        'negative': '#e74c3c'    # Red
                    }
                    
                    fig = px.scatter_geo(map_df,
                                lat='lat',
                                lon='lon',
                                color='sentiment',
                                color_discrete_map=color_discrete_map,
                                hover_name='airline',
                                hover_data=['sentiment'],
                                projection='natural earth',
                                title='Global Distribution of Tweets by Sentiment')
                    
                    fig.update_layout(
                        geo=dict(
                            showland=True,
                            landcolor="rgb(243, 243, 243)",
                            countrycolor="rgb(204, 204, 204)",
                        ),
                        margin={"r":0,"t":40,"l":0,"b":0}
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # 3. AIRLINE-SPECIFIC GEO DISTRIBUTION
                    st.markdown("### Airline-Specific Geographic Distribution")
                    
                    selected_airline = st.selectbox(
                        'Select Airline:',
                        sorted(geo_data['airline'].unique())
                    )
                    
                    airline_geo = geo_data[geo_data['airline'] == selected_airline]
                    
                    if not airline_geo.empty:
                        # Create density map
                        st.markdown(f"#### Tweet Density for {selected_airline}")
                        
                        # Show top locations
                        top_locations = airline_geo['approx_location'].value_counts().head(10).reset_index()
                        top_locations.columns = ['Approximate Location', 'Tweet Count']
                        
                        col1, col2 = st.columns([2, 1])
                        
                        with col1:
                            # Show map
                            st.map(airline_geo[['latitude', 'longitude']].rename(
                                columns={'latitude': 'lat', 'longitude': 'lon'}))
                        
                        with col2:
                            # Show top locations table
                            st.markdown("**Top Locations:**")
                            st.dataframe(top_locations, hide_index=True)
                        
                        # Sentiment distribution by location
                        st.markdown(f"#### Sentiment Distribution for {selected_airline}")
                        
                        location_sentiment = airline_geo.groupby(
                            ['approx_location', 'airline_sentiment']
                        ).size().unstack().fillna(0)
                        
                        fig = px.bar(location_sentiment.head(10),
                                    barmode='group',
                                    title=f'Sentiment at Top Locations for {selected_airline}',
                                    color_discrete_map=color_discrete_map)
                        
                        fig.update_layout(
                            xaxis_title='Approximate Location',
                            yaxis_title='Number of Tweets',
                            legend_title='Sentiment'
                        )
                        
                        st.plotly_chart(fig, use_container_width=True)
                    else:
                        st.warning(f"No geographic data available for {selected_airline}")
                    
                    # 4. ADDITIONAL ANALYSIS USING AVAILABLE COLUMNS
                    st.markdown("### Additional Insights")
                    
                    # Top users overall (not by region)
                    if 'name' in geo_data.columns:
                        st.markdown("#### Most Active Users")
                        top_users = geo_data['name'].value_counts().head(10).reset_index()
                        top_users.columns = ['User', 'Tweet Count']
                        
                        fig = px.bar(top_users,
                                    x='User',
                                    y='Tweet Count',
                                    title='Top Twitter Users',
                                    color='Tweet Count',
                                    color_continuous_scale='Viridis')
                        fig.update_layout(xaxis_tickangle=45)
                        st.plotly_chart(fig, use_container_width=True)
                    
                    # Retweet analysis
                    if 'retweet_count' in geo_data.columns:
                        st.markdown("#### Most Retweeted Content")
                        top_retweets = geo_data.sort_values('retweet_count', ascending=False).head(5)
                        
                        for i, row in top_retweets.iterrows():
                            st.markdown(f"**{row['retweet_count']} retweets:** {row['text']}")
                            st.markdown(f"*Airline: {row['airline']}, Sentiment: {row['airline_sentiment']}*")
                            st.markdown("---")
        
        # SECTION: WORD CLOUD ANALYSIS
        elif section == "Word Cloud Analysis":
            st.markdown("## Word Cloud Analysis")
            
            # Select sentiment for word cloud
            word_sentiment = st.selectbox(
                'Select sentiment for word cloud analysis:',
                ('positive', 'neutral', 'negative'),
                key='wordcloud_sentiment'
            )
            
            # Select airlines for word cloud
            word_cloud_airlines = st.multiselect(
                "Select airlines for word cloud:",
                sorted(data['airline'].unique()),
                default=sorted(data['airline'].unique())[0]
            )
            
            if not word_cloud_airlines:
                st.warning("Please select at least one airline")
            else:
                # Filter data for selected airlines and sentiment
                cloud_data = data[
                    (data['airline'].isin(word_cloud_airlines)) & 
                    (data['airline_sentiment'] == word_sentiment)
                ]
                
                if cloud_data.empty:
                    st.info(f"No {word_sentiment} tweets found for the selected airlines")
                else:
                    # Generate word cloud
                    st.markdown(f"### Word Cloud for {word_sentiment.capitalize()} Tweets")
                    
                    # Combine all text
                    all_text = ' '.join(cloud_data['text'])
                    
                    # Process text to remove http links, @mentions, and RT
                    processed_text = ' '.join([
                        word for word in all_text.split() 
                        if 'http' not in word and not word.startswith('@') and word != 'RT'
                    ])
                    
                    # Generate word cloud
                    wordcloud_colors = {
                        'positive': 'Greens',
                        'neutral': 'Oranges',
                        'negative': 'Reds'
                    }
                    
                    wordcloud = WordCloud(
                        stopwords=stop_words,
                        background_color='white',
                        colormap=wordcloud_colors[word_sentiment],
                        width=800,
                        height=400,
                        max_words=100
                    ).generate(processed_text)
                    
                    # Display word cloud
                    plt.figure(figsize=(10, 6))
                    plt.imshow(wordcloud, interpolation='bilinear')
                    plt.axis('off')
                    st.pyplot(plt)
                    
                    # Show most common words
                    st.markdown(f"### Most Common Words in {word_sentiment.capitalize()} Tweets")
                    
                    # Get word frequencies
                    words = processed_text.lower().split()
                    word_freq = {}
                    
                    for word in words:
                        if word not in stop_words and len(word) > 2:
                            if word in word_freq:
                                word_freq[word] += 1
                            else:
                                word_freq[word] = 1
                    
                    # Convert to DataFrame and sort
                    word_freq_df = pd.DataFrame(list(word_freq.items()), columns=['Word', 'Frequency'])
                    word_freq_df = word_freq_df.sort_values(by='Frequency', ascending=False).head(20)
                    
                    # Display as bar chart
                    fig = px.bar(word_freq_df, x='Word', y='Frequency', color='Frequency',
                                color_continuous_scale=wordcloud_colors[word_sentiment])
                    
                    fig.update_layout(
                        plot_bgcolor='rgba(0,0,0,0)',
                        paper_bgcolor='rgba(0,0,0,0)',
                        xaxis={'categoryorder':'total descending'},
                        xaxis_title="",
                        yaxis_title="Frequency"
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Show tweet examples
                    st.markdown(f"### Sample {word_sentiment.capitalize()} Tweets")
                    
                    sample_tweets = cloud_data['text'].sample(min(5, len(cloud_data)))
                    
                    for i, tweet in enumerate(sample_tweets):
                        st.markdown(f"**{i+1}.** {tweet}")
                        st.markdown("---")

        
except Exception as e:
    st.error(f"An error occurred while loading the data: {str(e)}")
    st.markdown("""
    ### Required Data Format
    
    This dashboard requires a CSV file with the following columns:
    - `airline_sentiment`: The sentiment of the tweet (positive, neutral, negative)
    - `airline`: The airline mentioned in the tweet
    - `text`: The text content of the tweet
    - `tweet_created`: The timestamp when the tweet was created
    
    Optional columns:
    - `tweet_lat` and `tweet_long`: Coordinates for mapping tweets
    - `negativereason`: The reason for negative sentiment
    """)